$ ballerina run any-type.bal
5
15
[1, 3, 5, 6]
cat